const mongoose = require("mongoose"); // Import mongoose to define the schema and model.

// Define the post schema using mongoose.Schema.
const postSchema = mongoose.Schema(
  {
    title: {
      type: String, // The type of the title field is String.
      required: [true, "title is required"], // Corrected spelling: 'require' to 'required'. This field is required with a custom error message.
      trim: true // Trim whitespace from the title value.
    },
    description: {
      type: String, // The type of the description field is String.
      required: [true, "description is required"], // Corrected spelling: 'require' to 'required'. This field is required with a custom error message.
      trim: true // Trim whitespace from the description value.
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId, // The type of the userId field is an ObjectId.
      ref: "User", // This field references the User model.
      required: true // The userId field is required.
    }
  },
  { timestamps: true }
); // Enable automatic timestamps for createdAt and updatedAt fields.

// Export the Post model based on the postSchema.
module.exports = mongoose.model("Post", postSchema);
