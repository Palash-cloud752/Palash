const {required} = require ('joi'); // Import Joi for validation (though it seems unused in this snippet).
const mongoose = require ('mongoose'); // Import mongoose to define the schema and model.

// Define the user schema using mongoose.Schema.
const userSchema = mongoose.Schema ({
  email: {
    type: String, // The type of the email field is String.
    required: [true, 'Email is required!'], // The email field is required with a custom error message.
    trim: true, // Trim whitespace from the email value.
    unique: [true, 'Email must be unique!'], // The email must be unique across documents with a custom error message.
    minLength: [5, 'Email must have 5 characters!'], // Minimum length of 5 characters for the email.
    lowercase: true, // Converts the email to lowercase.
  },
  password: {
    type: String, // The type of the password field is String.
    required: [true, 'Password must be provided!'], // The password field is required with a custom error message.
    trim: true, // Trim whitespace from the password value.
    select: false, // Exclude the password field from query results by default for security.
  },
  verified: {
    type: Boolean, // The type of the verified field is Boolean.
    default: false, // The default value of verified is false.
  },
  verificationCode: {
    type: String, // The type of the verificationCode field is String.
    select: false, // Exclude this field from query results by default for security.
  },
  verificationCodeValidation: {
    type: Number, // The type of the verificationCodeValidation field is Number.
    select: false, // Exclude this field from query results by default for security.
  },
  forgotPasswordCode: {
    type: String, // The type of the forgotPasswordCode field is String.
    select: false, // Exclude this field from query results by default for security.
  },
  forgotPasswordCodeValidation: {
    type: Number, // The type of the forgotPasswordCodeValidation field is Number.
    select: false, // Exclude this field from query results by default for security.
  },
}, {
    timestamps:true
});

const User = mongoose.model("User", userSchema);

module.exports = User;
