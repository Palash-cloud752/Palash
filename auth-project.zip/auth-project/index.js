const express = require("express");
const helmet = require("helmet");
const cors = require("cors"); // Require and import cors middleware for handling Cross-Origin Resource Sharing.
const cookieParser = require("cookie-parser"); // Import cookie-parser to parse cookies from incoming requests.
const mongoose = require("mongoose"); // Import mongoose to connect and interact with MongoDB.
const authRouter = require("./routers/authRouter"); // Correct import path for authRouter
const postsRouter = require('./routers/postsRouter')

const app = express();

// Middleware to enable CORS (Cross-Origin Resource Sharing).
app.use(cors());

// Middleware to enhance your app's security by setting various HTTP headers.
app.use(helmet());

// Middleware to parse incoming JSON requests.
app.use(express.json());

// Middleware to parse cookies from incoming requests.
app.use(cookieParser());

// Middleware to parse URL-encoded data from the body of incoming requests.
app.use(express.urlencoded({ extended: true }));

// Connect to MongoDB using the provided URI in the environment variables.
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("Database connected"); // Log a message when the database connection is successful.
  })
  .catch((err) => {
    console.log(err); // Log any errors that occur during the connection attempt.
  });

// Use the authRouter for routes starting with /api/auth.
app.use("/api/auth", authRouter);
app.use('/api/posts', postsRouter);

// Define a simple route to respond with a JSON message.
app.get("/", (req, res) => {
  res.json({ message: "Hello from the server" }); // Respond with a JSON message.
});

// Start the server on the specified port or default to 3000 if not provided.
app.listen(process.env.PORT || 3000, () => {
  console.log("listening...."); // Log a message when the server starts listening.
});
