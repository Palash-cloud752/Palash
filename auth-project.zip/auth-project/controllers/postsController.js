const { createPostSchema } = require("../middlewares/validator");
const post = require("../models/postsModel");

exports.getPosts = async (req, res) => {
  const { page } = req.query;
  const postsPerPage = 10;
  try {
    let pageNum = 0;
    if (page && page > 1) {
      pageNum = page - 1;
    }
    const result = await post
      .find()
      .sort({ createdAt: -1 })
      .skip(pageNum * postsPerPage)
      .limit(postsPerPage)
      .populate({
        path: "userId",
        select: "email"
      });
    res.status(200).json({ success: true, message: "posts", data: result });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

exports.singlePosts = async (req, res) => {
  const { _id } = req.query;
  try {
    const existingPost = await post.findOne({ _id }).populate({
      path: "userId",
      select: "email"
    });
    if (!existingPost) {
      return res
        .status(404)
        .json({ success: false, message: "Post unavailable" });
    }
    res
      .status(200)
      .json({ success: true, message: "Single post", data: existingPost });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

exports.createPost = async (req, res) => {
  const { title, description } = req.body;
  const { userId } = req.user;

  try {
    const { error } = createPostSchema.validate({ title, description, userId });

    if (error) {
      return res
        .status(400)
        .json({ success: false, message: error.details[0].message });
    }

    const result = await post.create({ title, description, userId });
    res.status(200).json({
      success: true,
      message: "Post created successfully",
      data: result
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

exports.updatePost = async (req, res) => {
  const { _id } = req.query;
  const { title, description } = req.body;
  const { userId } = req.user;

  try {
    const { error } = createPostSchema.validate({ title, description, userId });

    if (error) {
      return res
        .status(400)
        .json({ success: false, message: error.details[0].message });
    }

    const existingPost = await post.findOne({ _id });
    if (!existingPost) {
      return res
        .status(404)
        .json({ success: false, message: "Post already unavailable" });
    }

    if (existingPost.userId.toString() !== userId) {
      return res.status(403).json({ success: false, message: "Unauthorized" });
    }

    existingPost.title = title;
    existingPost.description = description;
    const result = await existingPost.save();
    res.status(200).json({
      success: true,
      message: "Post updated successfully",
      data: result
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

exports.deletePost = async (req, res) => {
  const { _id } = req.query;
  const { userId } = req.user;

  try {
    // Validate the post ID
    if (!_id) {
      return res
        .status(400)
        .json({ success: false, message: "Post ID is required" });
    }

    // Find the post by ID
    const existingPost = await post.findOne({ _id });
    if (!existingPost) {
      return res
        .status(404)
        .json({ success: false, message: "Post not found" });
    }

    // Check if the user is the owner of the post
    if (existingPost.userId.toString() !== userId) {
      return res.status(403).json({ success: false, message: "Unauthorized" });
    }

    // Delete the post
    await post.deleteOne({ _id });
    res
      .status(200)
      .json({ success: true, message: "Post deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};
