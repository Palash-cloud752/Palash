const jwt = require("jsonwebtoken");

exports.identifier = (req, res, next) => {
  let token;
  if (req.headers.client === "not-browser") {
    token = req.headers.authorization;
  } else {
    token = req.cookies["Authorization"];
  }

  if (!token) {
    return res.status(403).json({ success: false, message: "Unauthorized" });
  }

  try {
    // Ensure the token starts with 'Bearer ' and split it correctly
    if (token.startsWith("Bearer ")) {
      token = token.split(" ")[1];
    } else {
      throw new Error("Invalid token format");
    }

    const jwtVerified = jwt.verify(token, process.env.TOKEN_SECRET);

    if (jwtVerified) {
      req.user = jwtVerified;
      next();
    } else {
      throw new Error("Error in the token");
    }
  } catch (error) {
    console.error(error);
    res
      .status(403)
      .json({ success: false, message: "Invalid or expired token" });
  }
};
